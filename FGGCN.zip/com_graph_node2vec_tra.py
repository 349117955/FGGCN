import argparse
from FGGCN.com_graph_node2vec import ComGraph
from gensim.models import Word2Vec
import scipy.sparse as sp
import numpy as np
import csv


def read_graph():
    """
    读取networkx中的输入网络
    :return:
    """
    graph1_list = []
    graph2_list = []
    with open(args.graph1) as f:
        f_csv = csv.reader(f)
        for row in f_csv:
            edge1 = str(row).split(" ")[0][2:]
            edge2 = str(row).split(" ")[1][:-2]
            edges = (edge1, edge2)
            graph1_list.append(edges)

    with open(args.graph2) as f:
        f_csv = csv.reader(f)
        for row in f_csv:
            edge1 = str(row).split(" ")[0][2:]
            edge2 = str(row).split(" ")[1][:-2]
            edges = (edge1, edge2)
            graph2_list.append(edges)

    return graph1_list, graph2_list


def read_matrix():
    sparse_matrix1 = sp.csr_matrix(np.load(args.matrix_adjacency)['data'], dtype=bool)
    sparse_matrix2 = sp.csr_matrix(np.load(args.matrix_function)['data'], dtype=bool)
    return sparse_matrix1, sparse_matrix2


def learn_embeddings(walks):
    '''
    Learn embeddings by optimizing the Skipgram objective using SGD.
    '''
    walks = [list(map(str, walk)) for walk in walks]
    model = Word2Vec(walks, vector_size=args.dimensions, window=args.window_size, min_count=0, sg=1, workers=args.workers,
                     epochs=args.iter)
    model.wv.save_word2vec_format(args.node_embeddings)

    return


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--graph1', type=str, default='Graph_Edges/adjacency_edge_unweighted')
    parser.add_argument('--graph2', type=str, default='Graph_Edges/function_edge_unweighted')
    parser.add_argument('--matrix_adjacency', nargs='?', default='Attribute_Graphs/adjacency_graph.npz', help='adjacency_graph path')
    parser.add_argument('--matrix_function', nargs='?', default='Attribute_Graphs/function_graph.npz', help='function_graph path')
    parser.add_argument('--node_embeddings', type=str, default='Node_Embeddings/adj_fuc_node_embeddings.emb')
    parser.add_argument('--dimensions', type=int, default=128)
    parser.add_argument('--window_size', type=int, default=10)
    parser.add_argument('--workers', type=int, default=0)
    parser.add_argument('--iter', type=int, default=10)
    parser.add_argument('--p', type=float, default=1, help='Return hyperparameter. Default is 1.')
    parser.add_argument('--q', type=float, default=1, help='Inout hyperparameter. Default is 1.')
    parser.add_argument('--walk-length', type=int, default=240, help='Length of walk per source. Default is 80.')
    parser.add_argument('--num-walks', type=int, default=10, help='Number of walks per source. Default is 10.')

    args = parser.parse_args()

    graph1, graph2 = read_graph()
    graph_matrix1, graph_matrix2 = read_matrix()
    comGraph = ComGraph(graph1, graph2, graph_matrix1, graph_matrix2, is_directed=False, p=args.p, q=args.q)
    walks = comGraph.simulate_walks(args.num_walks, args.walk_length)
    learn_embeddings(walks)