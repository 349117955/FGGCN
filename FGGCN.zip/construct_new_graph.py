import pickle
import argparse
import numpy as np
import pandas as pd
import networkx as nx
import os


def get_cos_similar(v1, v2):
    num = float(np.dot(v1, v2))
    denom = np.linalg.norm(v1) * np.linalg.norm(v2)
    return 0.5 + 0.5 * (num / denom) if denom != 0 else 0


def learn_final_graph(threshold, filename, direct):
    def readEmbedFile(embedFile):
        input = open(embedFile, 'r')
        lines = []
        for line in input:
            lines.append(line)

        embeddings = {}
        for lineId in range(1, len(lines)):
            splits = lines[lineId].split(' ')
            embedId = int(splits[0])
            embedValue = splits[1:]
            new_embedValue = [float(x) for x in embedValue]
            embeddings[embedId] = new_embedValue

        embeddingsID = sorted(embeddings.keys())
        embeddings_sorted = {}
        for i in embeddingsID:
            embeddings_sorted[i] = embeddings[i]

        return embeddings_sorted

    embeddings = readEmbedFile(filename)

    index_list = []
    for index in embeddings.keys():
        index_list.append(index)

    num_nodes = len(index_list)
    cos_mx = np.zeros((num_nodes, num_nodes), dtype=np.float32)

    # for i in range(num_nodes):  # 主对角线为0
    #     for j in range(i + 1, num_nodes):
    #         embedding_i = np.asarray(embeddings[i])
    #         embedding_j = np.asarray(embeddings[j])
    #         cos_value = get_cos_similar(embedding_i, embedding_j)
    #         cos_mx[i][j] = cos_mx[j][i] = cos_value

    for i in range(num_nodes):
        for j in range(num_nodes):
            embedding_i = np.asarray(embeddings[i])
            embedding_j = np.asarray(embeddings[j])
            cos_value = get_cos_similar(embedding_i, embedding_j)
            cos_mx[i][j] = cos_value

    learn_mx = np.zeros((num_nodes, num_nodes), dtype=np.float32)
    for row in range(num_nodes):  # 有向图
        indices = np.argsort(cos_mx[row])[::-1][:threshold]  # 每行取前top k个最大值，返回对应的一维索引数组
        norm = cos_mx[row, indices].sum()
        for index in indices:
            learn_mx[row, index] = cos_mx[row, index] / norm

    if not direct:
        learn_mx = np.maximum.reduce([learn_mx, learn_mx.T])
        print('最终学的的图是无向图')
    else:
        print('最终学的的图是非对称矩阵')
    print(learn_mx)

    return learn_mx


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--filename_emb', type=str, default='Node_Embeddings/adj_fuc_node_embeddings.emb',
                        help='CSV file containing sensor distances with three columns: [from, to, distance].')
    parser.add_argument('--output_pkl_filename', type=str, default='Constructed_Graphs/adj_fuc_graph_18',
                        help='Path of the output file.')
    parser.add_argument('--thresh_cos', type=float, default=18,
                        help='Threshold used in constructing final graph.')
    parser.add_argument('--direct_L', type=bool, default=False,
                        help='Whether is the final graph directed or undirected.')
    args = parser.parse_args()

    output_pkl_filename = args.output_pkl_filename + '.pkl'
    print(output_pkl_filename)
    #
    if os.path.exists(args.filename_emb):
        learn_graph = learn_final_graph(args.thresh_cos, filename=args.filename_emb,
                                        direct=args.direct_L)
        with open(output_pkl_filename, 'wb') as f:
            pickle.dump(learn_graph, f, protocol=2)