import pickle
import scipy.sparse as sp
import torch
import argparse
import numpy as np
import networkx as nx
import random
import os


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

set_seed(2023)


def read_graphs():
    with open(args.new_graph_filename, 'rb') as f:
        pickle_data = pickle.load(f)

    return torch.FloatTensor(pickle_data)


class DropoutEdge(torch.nn.Module):
    def __init__(self, graph_matrix, close_threshold=0.1, dropout=0.1):
        super(DropoutEdge, self).__init__()

        self.graph_matrix = graph_matrix
        self.close_threshold = close_threshold
        self.dropout = dropout
        self.weight = torch.nn.Parameter(torch.FloatTensor())

        self.pruning_random = False
        # self.graph_matrix_dropouted = None

        self.G = nx.Graph()

        self.shape_size = len(self.graph_matrix)
        self.sparse_graph = self.get_sparse_graph()
        self.nx_graph = self.get_nxGraph_info()
        self.closeness_sorted = self.get_ClosenessCentrality()
        self.edges, self.values = self.get_edge_info()

        self.graph_matrix_dropouted = torch.ones_like(graph_matrix)


    def nodropout_edges(self):
        graph_matrix = self.graph_matrix
        normed_graph_matrix = self.get_norm_adj(graph_matrix)

        return normed_graph_matrix



    def dropout_edges(self):
        edges = self.edges
        values = self.values
        dropout = self.dropout
        pruning_random = self.pruning_random
        graph_matrix = self.graph_matrix
        graph_matrix_dropouted = self.graph_matrix_dropouted

        if dropout <= .0:
            graph_matrix_dropouted = graph_matrix
            return
        # keep_len = int(values.size(0) * (1. - dropout))
        keep_len = int(values.size(0) * dropout)

        if pruning_random:
            keep_idx = torch.tensor(random.sample(range(edges.size(0)), keep_len)).to(self.device)
        else:
            keep_idx = torch.multinomial(values, keep_len)
        keep_indices = edges[:, keep_idx]
        keep_indices_close = self.get_node_choice(keep_indices)
        # keep_values_close = torch.zeros_like(keep_indices_close[0])
        # all_values_close = torch.cat((keep_values_close, keep_values_close))
        all_indices_close = torch.cat((keep_indices_close, torch.flip(keep_indices_close, [0])), 1)
        # graph_matrix_dropouted = torch.ones_like(graph_matrix)

        for i in range(len(graph_matrix_dropouted)):
            for j in range(len(graph_matrix_dropouted)):
                if i in all_indices_close[0] and j in all_indices_close[1]:
                    graph_matrix_dropouted[i][j] = 0
                else:
                    graph_matrix_dropouted[i][j] = graph_matrix[i][j]

        normed_matrix_dropouted =self.get_norm_adj(graph_matrix_dropouted)

        return normed_matrix_dropouted



    def get_sparse_graph(self):
        shape_size = self.shape_size
        graph_matrix = self.graph_matrix

        rows = []
        cols = []
        values = []
        for i in range(len(graph_matrix)):
            for j in range(len(graph_matrix)):
                if graph_matrix[i][j] != 0.:
                    rows.append(i)
                    cols.append(j)
                    values.append(graph_matrix[i][j])

        return sp.coo_matrix((torch.FloatTensor(values), (rows, cols)), shape=[shape_size, shape_size])


    def get_nxGraph_info(self):
        sparse_graph = self.sparse_graph

        G = self.G
        rows = torch.from_numpy(sparse_graph.row)
        cols = torch.from_numpy(sparse_graph.col)
        rows_arr = np.array(rows)
        cols_arr = np.array(cols)

        G_list = []
        for i in range(0, np.size(rows_arr)):
            G_list.append((rows_arr[i], cols_arr[i]))
        G.add_edges_from(G_list)

        return G


    def get_edge_info(self):
        sparse_graph = self.sparse_graph

        rows = torch.from_numpy(sparse_graph.row)
        cols = torch.from_numpy(sparse_graph.col)
        edges = torch.stack([rows, cols]).type(torch.LongTensor)
        # edge normalized values
        values = self.normalize_adj(edges)

        return edges, values


    def normalize_adj(self, edges_indices):
        shape_size = self.shape_size

        adj = torch.sparse.FloatTensor(edges_indices, torch.ones_like(edges_indices[0]),
                                       torch.Size((shape_size, shape_size)))
        row_sum = 1e-7 + torch.sparse.sum(adj, -1).to_dense()
        col_sum = 1e-7 + torch.sparse.sum(adj.t(), -1).to_dense()
        r_inv_sqrt = torch.pow(row_sum, -0.5)
        rows_inv_sqrt = r_inv_sqrt[edges_indices[0]]
        c_inv_sqrt = torch.pow(col_sum, -0.5)
        cols_inv_sqrt = c_inv_sqrt[edges_indices[1]]
        values = rows_inv_sqrt * cols_inv_sqrt

        return values


    def get_ClosenessCentrality(self):
        nx_graph = self.nx_graph
        closeness = []
        node_list = []
        close_list = []
        for i in nx_graph.nodes():
            sumdij = 0
            for j in nx_graph.nodes():
                if (i != j):
                    try:
                        sumdij += nx.dijkstra_path_length(nx_graph, source=i, target=j)
                    except:
                        continue
            di = sumdij / nx.number_of_nodes(nx_graph)
            if di == 0:
                closeness.append((i, di))
            else:
                closeness.append((i, 1 / di))

        for node_close in closeness:
            node_list.append(node_close[0])
            close_list.append(node_close[1])

        closeness_dict = dict(zip(node_list, close_list))
        closeness_sorted = sorted(closeness_dict.items(), key=lambda item:item[1], reverse=True)

        return closeness_sorted


    def get_node_choice(self, keep_indices):
        closeness_sorted = self.closeness_sorted
        close_threshold = self.close_threshold

        num_close_nodes = int(len(closeness_sorted) * close_threshold)
        close_nodes = closeness_sorted[0: num_close_nodes]
        c_nodes_list = []
        for node in close_nodes:
            c_nodes_list.append(node[0])

        row_list = []
        col_list = []
        for i in range(len(keep_indices[0])):
            if (keep_indices[0][i] or keep_indices[1][i]) in c_nodes_list:
                row_list.append(keep_indices[0][i])
                col_list.append(keep_indices[1][i])
            else:
                continue

        keep_indices_close = torch.tensor([row_list, col_list])

        return keep_indices_close


    def get_norm_adj(self, gra_mat):
        gra_mat = gra_mat + np.eye(self.shape_size)
        A = sp.dok_matrix(gra_mat, dtype=np.float32) # 可操作的稀疏矩阵
        A_sparse_graph = self.get_sparse_graph()
        A_sparse_graph_t = A_sparse_graph.transpose()
        data_dict = dict(zip(zip(A_sparse_graph.row, A_sparse_graph.col), [1]*A_sparse_graph.nnz))
        data_dict.update(dict(zip(zip(A_sparse_graph_t.row, A_sparse_graph_t.col), [1]*A_sparse_graph_t.nnz)))
        A._update(data_dict)
        sumArr = (A > 0).sum(axis=1)
        diag = np.array(sumArr.flatten())[0] + 1e-7
        diag = np.power(diag, -0.5)
        D = sp.diags(diag)
        A_new = D * gra_mat * D
        A_new = torch.FloatTensor(A_new)

        return A_new



if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--new_graph_filename', type=str, default='Constructed_Graphs/adj_fuc_graph_22.pkl')
    parser.add_argument('--dropout_edge_pkl_filename', type=str, default='Dropout_Edges/adj_fuc_graph_dropouted_22_01_01',
                        help='Path of the output file.')
    # parser.add_argument('--dropout_edge_pkl_filename', type=str, default='Dropout_Edges/noDropout_adj_fuc_graph_dropouted06',
    #                     help='Path of the output file.')

    args = parser.parse_args()

    graph_matrix = read_graphs()
    print(graph_matrix)
    dropout_edge = DropoutEdge(graph_matrix)
    graph_matrix_dropouted = dropout_edge.dropout_edges()
    print(graph_matrix_dropouted)

    output_pkl_filename = args.dropout_edge_pkl_filename + '.pkl'

    with open(output_pkl_filename, 'wb') as f:
        pickle.dump(graph_matrix_dropouted, f, protocol=2)



    # graph_matrix = read_graphs()
    # dropout_edge = DropoutEdge(graph_matrix)
    # graph_matrix_dropouted = dropout_edge.nodropout_edges()
    # print(graph_matrix_dropouted)
    #
    # output_pkl_filename = args.dropout_edge_pkl_filename + '.pkl'
    #
    # with open(output_pkl_filename, 'wb') as f:
    #     pickle.dump(graph_matrix_dropouted, f, protocol=2)