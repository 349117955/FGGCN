from math import radians, cos, sin, asin
from math import sqrt
import pandas as pd
import argparse
import csv
import numpy as np


def calDistance(lat1, lng1, lat2, lng2):
    lng1, lat1, lng2, lat2 = map(radians, [float(lng1), float(lat1), float(lng2), float(lat2)])
    dlon = lng2 - lng1
    dlat = lat2 - lat1
    a = sin(dlat / 2) ** 2 + cos(lat1) * cos(lat2) * sin(dlon / 2) ** 2
    distances = 2 * asin(sqrt(a)) * 6371 * 1000
    distance = round(distances / 1000, 3)
    return distance

def adjacency_df(sensor_location_files, adjacency_threshold):
    sigma = 29.1501
    dist_adj = []
    ds = pd.read_csv(sensor_location_files, encoding='gbk')
    station_array = ['HuaiHeDao', 'HaiTaiFaZhan', 'XinHuaDao', 'FuKangLu', 'JianCeZhongXin', 'DaZhiGu',
                     'XiangShanDao', 'NanJingLu', 'QinJianDao', 'QianJinDao', 'NanKouLu', 'JinGuLu', 'HanBeiLu',
                     'DiSiDaJie', 'YongMingLu', 'HangTianLu', 'YueJinLu', 'DongHuanLu', 'JianSheLu', 'BaoBaiGongLu',
                     'HeXiYiJing', 'GuangAnDao', 'BeiWeiErLu', 'TuanBoWa', 'TangGuYingKou', 'QuanZhouNanLu']
    for i in range(len(ds)):
        station_lat = ds['lat'][i]
        station_lng = ds['lng'][i]
        station = station_array[i]
        dist_ = []
        for j in range(len(ds)):
            station_lat1 = ds['lat'][j]
            station_lng1 = ds['lng'][j]
            station1 = station_array[j]
            dist = calDistance(station_lat1, station_lng1, station_lat, station_lng)
            if dist > adjacency_threshold:
                dist = 0
            else:
                dist = np.exp(-(dist ** 2) / sigma ** 2)
                if station != station1:
                    dist_.append([station, station1, dist])
        dist_adj.append(dist_)
    return dist_adj


def Generate_adjacency_files(adjacency_df_files, sensor_location_files, adjacency_threshold):
    f = open(adjacency_df_files, 'r+', encoding='utf-8', newline='')
    writer = csv.writer(f)
    for line in adjacency_df(sensor_location_files, adjacency_threshold):
        for line1 in line:
            writer.writerow(line1)


# --------------------------------------------------Function--------------------------------------------------
def function_df(sensor_function_files, function_threshold):
    poi = pd.read_csv(sensor_function_files)
    station_array = ['HuaiHeDao', 'HaiTaiFaZhan', 'XinHuaDao', 'FuKangLu', 'JianCeZhongXin', 'DaZhiGu',
                         'XiangShanDao', 'NanJingLu', 'QinJianDao', 'QianJinDao', 'NanKouLu', 'JinGuLu', 'HanBeiLu',
                         'DiSiDaJie', 'YongMingLu', 'HangTianLu', 'YueJinLu', 'DongHuanLu', 'JianSheLu', 'BaoBaiGongLu',
                         'HeXiYiJing', 'GuangAnDao', 'BeiWeiErLu', 'TuanBoWa', 'TangGuYingKou', 'QuanZhouNanLu']
    func_adj = []
    for station in station_array:
        st_poi = poi[station].values.tolist()
        eu_dist = []
        for station1 in station_array:
            st_poi1 = poi[station1].values.tolist()
            eu_dist_sum = 0
            for i in range(len(st_poi)):
                euclidean_distance = (st_poi[i] - st_poi1[i]) ** 2
                eu_dist_sum += euclidean_distance
            if eu_dist_sum == 0:
                eu_dist_sum = 1
            eu_dist_sum = 1 / eu_dist_sum
            if eu_dist_sum < function_threshold:
                eu_dist_sum = 0
            if eu_dist_sum >= function_threshold:
                if station != station1:
                    eu_dist.append([station, station1, eu_dist_sum])
        func_adj.append(eu_dist)
    return func_adj

def Generate_function_files(function_df_files, sensor_function_files, function_threshold):
    f = open(function_df_files, 'r+', encoding='utf-8', newline='')
    writer = csv.writer(f)
    for line in function_df(sensor_function_files, function_threshold):
        for line1 in line:
            writer.writerow(line1)


# --------------------------------------------------Temporal--------------------------------------------------
def multipl(a, b):
    sumofab = 0.0
    for i in range(len(a)):
        temp = a[i] * b[i]
        sumofab += temp
    return sumofab

def corrcoef(x, y):
    n = len(x)
    # 求和
    sum1 = sum(x)
    sum2 = sum(y)
    # 求乘积之和
    sumofxy = multipl(x, y)
    # 求平方和
    sumofx2 = sum([pow(i, 2) for i in x])
    sumofy2 = sum([pow(j, 2) for j in y])
    num = sumofxy - (float(sum1) * float(sum2) / n)
    # 计算皮尔逊相关系数
    den = sqrt((sumofx2 - float(sum1 ** 2) / n) * (sumofy2 - float(sum2 ** 2) / n))
    if den == 0:
        return 0
    return num / den

def temporal_df(sensor_temporal_files, temporal_threshold):
    average = pd.read_csv(sensor_temporal_files)
    station_array = ['6001', '6002', '6007', '6003', '6028', '6004', '6006', '6005', '6008', '6010', '6011', '6012',
                         '6020', '6022', '6024', '6013', '6014', '6015', '6016', '6017', '6019', '6021', '6025', '6026',
                         '6023', '6027']
    pattern_adj = []
    for station in station_array:
        pattern_pear = []
        for station1 in station_array:
            values = average[station].values.tolist()
            values1 = average[station1].values.tolist()
            pearson = corrcoef(values, values1)
            if pearson < temporal_threshold:
                pearson = 0
            if pearson == 1.0:
                pearson = 0
            if pearson > temporal_threshold:
                if station != station1:
                    pattern_pear.append([station, station1, pearson])
        pattern_adj.append(pattern_pear)
    return pattern_adj

def Generate_temporal_files(temporal_df_files, sensor_temporal_files, temporal_threshold):
    f = open(temporal_df_files, 'r+', encoding='utf-8', newline='')
    writer = csv.writer(f)
    for line in temporal_df(sensor_temporal_files, temporal_threshold):
        for line1 in line:
            writer.writerow(line1)


# --------------------------------------------------SensorID--------------------------------------------------
def Generate_sensorID_files(sensorID_files):
    f = open(sensorID_files, 'r+', encoding='utf-8', newline='')
    writer = csv.writer(f)
    station_array = ['HuaiHeDao', 'HaiTaiFaZhan', 'XinHuaDao', 'FuKangLu', 'JianCeZhongXin', 'DaZhiGu',
                         'XiangShanDao', 'NanJingLu', 'QinJianDao', 'QianJinDao', 'NanKouLu', 'JinGuLu', 'HanBeiLu',
                         'DiSiDaJie', 'YongMingLu', 'HangTianLu', 'YueJinLu', 'DongHuanLu', 'JianSheLu', 'BaoBaiGongLu',
                         'HeXiYiJing', 'GuangAnDao', 'BeiWeiErLu', 'TuanBoWa', 'TangGuYingKou', 'QuanZhouNanLu']
    for station in station_array:
        writer.writerow([station])



if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--sensor_location_files', type=str, default='Raw_Data/station_tj111.csv')
    parser.add_argument('--adjacency_df_files', type=str, default='DF_Data/adjacency_df.csv')
    parser.add_argument('--adjacency_threshold', type=int, default=30)
    parser.add_argument('--sensor_function_files', type=str, default='Raw_Data/poi _tj111.csv')
    parser.add_argument('--function_df_files', type=str, default='DF_Data/function_df.csv')
    parser.add_argument('--function_threshold', type=float, default=5e-06)
    parser.add_argument('--sensor_temporal_files', type=str, default='Raw_Data/month_average_pm251.csv')
    parser.add_argument('--temporal_df_files', type=str, default='DF_Data/temporal_df.csv')
    parser.add_argument('--temporal_threshold', type=float, default=0.9)
    parser.add_argument('--sensorID_files', type=str, default='Sensor_ID/sensorID.csv')
    args = parser.parse_args()

    # Generate_adjacency_files(args.adjacency_df_files, args.sensor_location_files, args.adjacency_threshold)
    # Generate_function_files(args.function_df_files, args.sensor_function_files, args.function_threshold)
    # Generate_temporal_files(args.temporal_df_files, args.sensor_temporal_files, args.temporal_threshold)
    # Generate_sensorID_files(args.sensorID_files)
    # print(temporal_df(args.sensor_temporal_files, args.temporal_threshold))