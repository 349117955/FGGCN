import torch
import math
import numpy as np
import torch.nn.functional as F
from FGGCN.GRUcell7 import Cells
import random
from FGGCN.attention import Attention
import scipy.sparse as sp


class Encoder_Decoder(torch.nn.Module):
    def __init__(self):
        super(Encoder_Decoder, self).__init__()
        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self.hidden_size = 64
        self.m = 34
        self.forecast = 6
        self.stations = 26
        self.input_size = 34
        self.nhid_1 = 64
        self.nhid_2 = 64
        self.Ws = torch.nn.Parameter(torch.FloatTensor(self.m, self.m))
        self.Wt = torch.nn.Parameter(torch.FloatTensor(self.hidden_size, self.hidden_size))
        self.Wt_ = torch.nn.Parameter(torch.FloatTensor(self.hidden_size, self.hidden_size))
        self.bt = torch.nn.Parameter(torch.FloatTensor(self.hidden_size))
        self.vt = torch.nn.Parameter(torch.FloatTensor(self.hidden_size))
        self.ws = torch.nn.Parameter(torch.FloatTensor(self.hidden_size))
        self.att = Attention(self.hidden_size, 32)
        self.cells = Cells(self.hidden_size, self.input_size, self.nhid_1, self.nhid_2)
        self.cells2 = Cells(self.hidden_size, self.hidden_size, self.nhid_1, self.nhid_2)
        self.dcells = Cells(self.hidden_size, self.hidden_size, self.nhid_1, self.nhid_2)
        self.reset_parameters()

    def reset_parameters(self):
        for weight in self.parameters():
            stdv = 1. / math.sqrt(weight.size(0))
            torch.nn.init.uniform_(weight, -stdv, stdv)


    def input_transform(self, x):
        local_inputs, labels = x
        #  16, 12, 34, 26      16, 6, 1, 26
        local_inputs = local_inputs.permute(1, 0, 2, 3)  # (12h, batch, feature, stations)
        labels = labels.permute(1, 0, 2, 3)  # (6h, batch, 1features, stations)
        n_input_encoder = local_inputs.data.size(2)  # 28features
        batch_size = local_inputs.data.size(1)
        _local_inputs = local_inputs.contiguous().view(-1, n_input_encoder, self.stations)
        _local_inputs = torch.split(_local_inputs, batch_size, 0)
        encoder_inputs = _local_inputs
        _labels = labels.contiguous().view(-1, self.stations)
        _labels = torch.split(_labels, batch_size, 0)  # （batch, 1, stations）
        _lastinp = local_inputs[11:12, :, 0:1, :]  # 1, 256, 1, 35
        _lastinp = _lastinp.contiguous().view(-1, 1, self.stations)
        _lastinp = torch.split(_lastinp, batch_size, 0)
        decoder_inputs = list(_lastinp) + list(_labels[:-1])  # 6*(256, 1, 35)
        return encoder_inputs, _labels, decoder_inputs

    def Encoder(self, encoder_inputs, As_Af, As_Af_drop):
        Inputs = encoder_inputs  # 12 (batch, feature, stations)
        batch_size = Inputs[0].data.size(0)
        stations = Inputs[0].data.size(2)
        lasth_As_Af = torch.rand(batch_size, stations, self.hidden_size)
        hlist_As_Af = []

        for flinput in Inputs:
            flinputx = flinput.permute(0, 2, 1)  # stations, feature,
            flinput = torch.as_tensor(flinput, dtype=torch.float32).to(self.device)
            flinputx = torch.as_tensor(flinputx, dtype=torch.float32).to(self.device)
            top = torch.exp(torch.sigmoid(torch.matmul(torch.matmul(flinputx, self.Ws.to(self.device)), flinput)))
            bottom = torch.sum(top, dim=1)  # (m,1)
            #             bottom = bottom.unsqueeze(2).repeat(1,1,top.data.size(2))
            bottom = bottom.reshape(batch_size, -1, 1)  # 16,26,1
            S = torch.div(top, bottom)  # 16,26,26
            # As_Af_new = As_Af.to(self.device) * S
            As_Af_new = torch.mul(As_Af.to(self.device), S)
            As_Af_drop_new = torch.mul(As_Af_drop.to(self.device), S)



            h1_As_Af = self.cells(flinputx, As_Af_new, As_Af_drop_new, lasth_As_Af)
            h2_As_Af = self.cells2(h1_As_Af, As_Af_new, As_Af_drop_new, lasth_As_Af)


            lasth_As_Af = h2_As_Af
            hlist_As_Af.append(h2_As_Af)

        return hlist_As_Af

    def Decoder(self, As_Af, As_Af_drop, decoder_inputs, encoder_inputs, hlist_As_Af, teather_ratio):
        Inputs = encoder_inputs
        batch_size = Inputs[0].data.size(0)
        stations = Inputs[0].data.size(2)
        lasth_As_Af = torch.rand(batch_size, stations, self.hidden_size)
        predicts = []
        for dint in decoder_inputs:
            sumalfa1 = torch.zeros(batch_size, stations, self.hidden_size).to(self.device)
            alfalist1 = []
            for h_As_Af in hlist_As_Af:
                alfa = torch.matmul(torch.tanh(
                    torch.matmul(h_As_Af.to(self.device), self.Wt) + torch.matmul(lasth_As_Af.to(self.device),
                                                                                 self.Wt_) + self.bt), self.vt)
                alfa = alfa.reshape(batch_size, -1, 1)
                alfalist1.append(torch.exp(alfa))
                sumalfa1 = sumalfa1 + torch.exp(alfa)
            C1 = torch.zeros(batch_size, stations, self.hidden_size).to(self.device)
            for h_As_Af, alfa in zip(hlist_As_Af, alfalist1):
                alfa = torch.div(h_As_Af, sumalfa1)
                C1 = C1 + alfa * h_As_Af

            ran_t = random.random()
            is_teather = ran_t < teather_ratio
            dint = dint.reshape(batch_size, self.stations, 1).float().repeat(1, 1, self.hidden_size)
            C1 = (dint if is_teather else C1)

            d_As_Af = self.dcells(C1, As_Af, As_Af_drop, lasth_As_Af)
            lasth_As_Af = d_As_Af
            ypredict = torch.tanh(torch.matmul(d_As_Af, self.ws))
            predicts.append(ypredict)
        return predicts

    def forward(self, x, As_Af, As_Af_drop, teather_ratio):
        encoder_inputs, labels, decoder_inputs = self.input_transform(x)
        hlist_As_Af = self.Encoder(encoder_inputs, As_Af, As_Af_drop)
        predicts = self.Decoder(As_Af, As_Af_drop, decoder_inputs, encoder_inputs, hlist_As_Af, teather_ratio)

        return predicts, labels
