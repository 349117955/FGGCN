import torch
from FGGCN.gcn_layer import GCN_Layer
from FGGCN.attention import Attention


class Cells(torch.nn.Module):
    def __init__(self, hidden_size, input_size):
        super(Cells, self).__init__()

        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self.hidden_size = hidden_size
        self.input_size = input_size
        self.attn_layer1 = Attention(self.input_size, 8)
        self.attn_layer2 = Attention(self.input_size, 8)
        self.attn_layer3 = Attention(self.input_size, 8)
        self.attn_layer4 = Attention(self.input_size, 8)
        self.attn_drop_layer1 = Attention(self.input_size, 8)
        self.attn_drop_layer2 = Attention(self.input_size, 8)
        self.attn_drop_layer3 = Attention(self.input_size, 8)
        self.attn_drop_layer4 = Attention(self.input_size, 8)
        self.attn_drop_layer5 = Attention(self.input_size, 8)
        self.attn_drop_layer6 = Attention(self.input_size, 8)
        self.attn_fuse = Attention(self.input_size, 8)
        self.gcn_layer1 = GCN_Layer()
        self.gcn_layer2 = GCN_Layer()
        self.gcn_layer3 = GCN_Layer()
        self.gcn_layer4 = GCN_Layer()
        self.gcn_drop_layer1 = GCN_Layer()
        self.gcn_drop_layer2 = GCN_Layer()
        self.gcn_drop_layer3 = GCN_Layer()
        self.gcn_drop_layer4 = GCN_Layer()
        self.gcn_drop_layer5 = GCN_Layer()
        self.gcn_drop_layer6 = GCN_Layer()


        self.Wr_As_Af = torch.nn.Linear(self.hidden_size + self.input_size, self.hidden_size, bias=False)
        self.Wz_As_Af = torch.nn.Linear(self.hidden_size + self.input_size, self.hidden_size, bias=False)
        self.Wh_As_Af = torch.nn.Linear(self.hidden_size + self.input_size, self.hidden_size, bias=False)

    def forward(self, x1, adj_As_Af, drop_adj_As_Af, hidden_As_Af):

        o_As_Af1 = self.gcn_layer1(x1, adj_As_Af)
        out_z1 = torch.stack([o_As_Af1, x1], dim=1)
        o_As_Af_attn1, _ = self.attn_layer1(out_z1)
        o_As_Af2 = self.gcn_layer2(o_As_Af_attn1, adj_As_Af)
        out_z2 = torch.stack([o_As_Af2, o_As_Af_attn1], dim=1)
        o_As_Af_attn2, _ = self.attn_layer2(out_z2)
        o_As_Af3 = self.gcn_layer3(o_As_Af_attn2, adj_As_Af)
        out_z3 = torch.stack([o_As_Af3, o_As_Af_attn2], dim=1)
        o_As_Af_attn3, _ = self.attn_layer3(out_z3)
        o_As_Af4 = self.gcn_layer4(o_As_Af_attn3, adj_As_Af)
        out_z4 = torch.stack([o_As_Af4, o_As_Af_attn3], dim=1)
        o_As_Af_attn4, _ = self.attn_layer4(out_z4)


        o_As_Af1_drop = self.gcn_drop_layer1(x1, drop_adj_As_Af)
        out_drop_z1 = torch.stack([o_As_Af1_drop, x1], dim=1)
        o_As_Af_drop_att1, _ = self.attn_drop_layer1(out_drop_z1)
        o_As_Af2_drop = self.gcn_drop_layer2(o_As_Af_drop_att1, drop_adj_As_Af)
        out_drop_z2 = torch.stack([o_As_Af2_drop, o_As_Af_drop_att1], dim=1)
        o_As_Af_drop_att2, _ = self.attn_drop_layer2(out_drop_z2)
        o_As_Af3_drop = self.gcn_drop_layer3(o_As_Af_drop_att2, drop_adj_As_Af)
        out_drop_z3 = torch.stack([o_As_Af3_drop, o_As_Af_drop_att2], dim=1)
        o_As_Af_drop_att3, _ = self.attn_drop_layer3(out_drop_z3)
        o_As_Af4_drop = self.gcn_drop_layer4(o_As_Af_drop_att3, drop_adj_As_Af)
        out_drop_z4 = torch.stack([o_As_Af4_drop, o_As_Af_drop_att3], dim=1)
        o_As_Af_drop_att4, _ = self.attn_drop_layer4(out_drop_z4)
        o_As_Af5_drop = self.gcn_drop_layer5(o_As_Af_drop_att4, drop_adj_As_Af)
        out_drop_z5 = torch.stack([o_As_Af5_drop, o_As_Af_drop_att4], dim=1)
        o_As_Af_drop_att5, _ = self.attn_drop_layer5(out_drop_z5)
        o_As_Af6_drop = self.gcn_drop_layer6(o_As_Af_drop_att5, drop_adj_As_Af)
        out_drop_z6 = torch.stack([o_As_Af6_drop, o_As_Af_drop_att5], dim=1)
        o_As_Af_drop_att6, _ = self.attn_drop_layer6(out_drop_z6)


        out_As_Af = o_As_Af_attn1 + o_As_Af_attn2 + o_As_Af_attn3 + o_As_Af_attn4
        out_As_Af_drop = o_As_Af_drop_att1 + o_As_Af_drop_att2 + o_As_Af_drop_att3 + o_As_Af_drop_att4 + o_As_Af_drop_att5 + o_As_Af_drop_att6

        out_fuse = (out_As_Af + out_As_Af_drop) / 2

        x1_As_Af = torch.cat([out_fuse, hidden_As_Af.to(self.device)], dim=2)
        r_As_Af = torch.sigmoid(self.Wr_As_Af(x1_As_Af))
        z_As_Af = torch.sigmoid(self.Wz_As_Af(x1_As_Af))
        x2_As_Af = torch.cat([r_As_Af * hidden_As_Af.to(self.device), out_fuse], dim=2)
        h_As_Af_ = torch.tanh(self.Wh_As_Af(x2_As_Af))
        h_As_Af_ = (1 - z_As_Af) * hidden_As_Af.to(self.device) + z_As_Af * h_As_Af_

        return h_As_Af_