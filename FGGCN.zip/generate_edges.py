import argparse
import numpy as np
import networkx as nx
import csv



def read_file(files_name):
    f_ = []
    with open(files_name) as f:
        f_csv = csv.reader(f)
        for row in f_csv:
            f_.append(row)
    return f_


def get_weighted_matrix(properties_df, sensor_ids):
    """
    :param properties_df: 三列数据[from, to, 属性关系]
    :param sensor_ids: 传感器的id列表
    :return:
    """

    num_sensors = len(sensor_ids)
    properties_mx = np.zeros((num_sensors, num_sensors), dtype=np.float32)

    # 构建sensor ID 到索引的映射
    sensor_id_to_index = {}
    for i, sensor_id in enumerate(sensor_ids):
        sensor_id_to_index[sensor_id[0]] = i

    # 用属性填充矩阵中的单元格
    for row in properties_df:
        if row[0] not in sensor_id_to_index or row[1] not in sensor_id_to_index or len(row) != 3:
            continue
        properties_mx[sensor_id_to_index[row[0]], sensor_id_to_index[row[1]]] = row[2]
        properties_mx[sensor_id_to_index[row[1]], sensor_id_to_index[row[0]]] = row[2]

    adj_mx = properties_mx

    return sensor_ids, sensor_id_to_index, adj_mx


def construct_graph(properties_df, sensor_ids, filename):
    num_sensors = len(sensor_ids)
    properties_mx = np.zeros((num_sensors, num_sensors), dtype=np.float32)

    # 构建sensor ID 到索引的映射
    sensor_id_to_index = {}
    for i, sensor_id in enumerate(sensor_ids):
        sensor_id_to_index[sensor_id[0]] = i

    # 用属性填充矩阵中的单元格
    for row in properties_df:
        if row[0] not in sensor_id_to_index or row[1] not in sensor_id_to_index or len(row) != 3:
            continue
        # properties_mx[sensor_id_to_index[row[0]], sensor_id_to_index[row[1]]] = row[2]
        # properties_mx[sensor_id_to_index[row[1]], sensor_id_to_index[row[0]]] = row[2]
        properties_mx[sensor_id_to_index[row[0]], sensor_id_to_index[row[1]]] = row[2]
        properties_mx[sensor_id_to_index[row[1]], sensor_id_to_index[row[0]]] = row[2]
    graph = properties_mx
    np.savez(filename, data=graph)

    return graph


def consrtuct_edgelist(properties_df, sensor_ids, filename, weighted):
    G = nx.Graph()

    # 构建sensor ID 到索引的映射
    sensor_id_to_index = {}
    for i, sensor_id in enumerate(sensor_ids):
        sensor_id_to_index[sensor_id[0]] = i

    if weighted:
        for row in properties_df:
            if row[0] not in sensor_id_to_index or row[1] not in sensor_id_to_index or len(row) != 3:
                continue
            G.add_edge(sensor_id_to_index[row[0]], sensor_id_to_index[row[1]], weight=row[2])
        nx.write_weighted_edgelist(G, filename)
    else:
        for row in properties_df:
            if row[0] not in sensor_id_to_index or row[1] not in sensor_id_to_index or len(row) != 3:
                continue
            G.add_edge(sensor_id_to_index[row[0]], sensor_id_to_index[row[1]])
        nx.write_edgelist(G, filename, data=False)



if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--files_name_ids', type=str, default='Sensor_ID/sensorID.csv')

    # adjacency
    parser.add_argument('--files_adjacency_df', type=str, default='DF_Data/adjacency_df.csv')
    parser.add_argument('--filename_graph_adjacency', type=str, default='Attribute_Graphs/adjacency_graph')
    parser.add_argument('--filename_edge_adjacency_weighted', type=str, default='Graph_Edges/adjacency_edge_weighted')
    parser.add_argument('--filename_edge_adjacency_unweighted', type=str, default='Graph_Edges/adjacency_edge_unweighted')


    # function
    parser.add_argument('--files_function_df', type=str, default='DF_Data/function_df.csv')
    parser.add_argument('--filename_graph_function', type=str, default='Attribute_Graphs/function_graph')
    parser.add_argument('--filename_edge_function_weighted', type=str, default='Graph_Edges/function_edge_weighted')
    parser.add_argument('--filename_edge_function_unweighted', type=str, default='Graph_Edges/function_edge_unweighted')


    # temporal
    parser.add_argument('--files_temporal_df', type=str, default='DF_Data/temporal_df.csv')
    parser.add_argument('--filename_graph_temporal', type=str, default='Attribute_Graphs/temporal_graph')
    parser.add_argument('--filename_edge_temporal_weighted', type=str, default='Graph_Edges/temporal_edge_weighted')
    parser.add_argument('--filename_edge_temporal_unweighted', type=str, default='Graph_Edges/temporal_edge_unweighted')
    args = parser.parse_args()

    # parser.add_argument('--temporal_df_files', type=str, default='data/temporal_df.csv')

    # read_df = read_file(args.files_adjacency_df)
    # read_ids = read_file(args.files_name_ids)
    # construct_graph(read_df, read_ids, args.filename_graph_adjacency)
    # consrtuct_edgelist(read_df, read_ids, args.filename_edge_adjacency_weighted, weighted=True)
    # consrtuct_edgelist(read_df, read_ids, args.filename_edge_adjacency_unweighted, weighted=False)
    #
    # read_df = read_file(args.files_function_df)
    # read_ids = read_file(args.files_name_ids)
    # construct_graph(read_df, read_ids, args.filename_graph_function)
    # consrtuct_edgelist(read_df, read_ids, args.filename_edge_function_weighted, weighted=True)
    # consrtuct_edgelist(read_df, read_ids, args.filename_edge_function_unweighted, weighted=False)
    #
    # read_df = read_file(args.files_temporal_df)
    # read_ids = read_file(args.files_name_ids)
    # construct_graph(read_df, read_ids, args.filename_graph_temporal)
    # consrtuct_edgelist(read_df, read_ids, args.filename_edge_temporal_weighted, weighted=True)
    # consrtuct_edgelist(read_df, read_ids, args.filename_edge_temporal_unweighted, weighted=False)





