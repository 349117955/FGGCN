import torch
import math

class GCN_Layer(torch.nn.Module):
    def __init__(self, in_feat, out_feat):
        super(GCN_Layer, self).__init__()
        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self.in_feat = in_feat
        self.out_feat = out_feat
        self.weight = torch.nn.Parameter(torch.FloatTensor(self.in_feat, self.out_feat))
        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.weight.size(1))
        self.weight.data.uniform_(-stdv, stdv)

    def forward(self, input, dropout_adj):
        support = torch.matmul(input, self.weight)
        output = torch.matmul(dropout_adj.to(self.device), support)

        return output