import torch
import math

class GCN_Layer(torch.nn.Module):
    def __init__(self):
        super(GCN_Layer, self).__init__()
        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


    def forward(self, input, adj):
        output = torch.matmul(adj.to(self.device), input)

        return output